function valid()
        {
            var fname=document.getElementById("fn");
            var mbl=document.getElementById("ph");
            var pass=document.getElementById("pw");
            var cpw=document.getElementById("cpw");
            var regn=/^[6789]\d{9}$/;
            var regp=/^[a-zA-Z0-9]+$/;
            var regu=/^[A-z a-z]+$/;
            if(fname.value.trim()=="")
            {
                document.getElementById("spu").innerHTML="*user name should not be empty";

                uname.style.borderColor='red';
                return false;
            }
            else if(!fname.value.match(regu))
            {
                alert("only letters are allowes");
                return false;
            }
            else if(mbl.value.trim()=="")
            {
                document.getElementById("spu1").innerHTML="*Mobile number should not be empty";
                mbl.style.borderColor='red';
                return false;
            }
           
            else if(!mbl.value.match(regn))
            {
                alert("please check the mbl number");
                return false;
            }
            else if(pass.value.trim()=="")
            {
                document.getElementById("spu2").innerHTML="*Password box should not be empty";
                pass.style.borderColor='red';
                return false;
            }
            else if(!pass.value.match(regp))
            {
                alert("password must contain atleast one lowercase,one uppercase,one number");
                return false;
            }
            else if(cpw.value.trim()=="" )
            {
                document.getElementById("spu3").innerHTML="*con-Password box should not be empty";
                pass.style.borderColor='red';        
                return false;
            }
           
            else if(pass.value.trim()!=cpw.value.trim())
            {
                alert(" password not matched");
                return false;
            }
            
            else if(pass.value.trim().length<7)
            {
                alert("password too shord");
                return false;
            }
            else
            {
                return true;
            } 
           
        }